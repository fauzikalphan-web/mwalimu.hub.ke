# Mwalimu Hub KE

**Learn • Practice • Excel**

Implementation foundation for the Mwalimu Hub KE educational platform.

## Current build
- Flutter Android learner app foundation
- Node.js/TypeScript REST API
- Prisma/PostgreSQL schema
- JWT authentication
- Learner progress
- Published lesson access
- Quiz retrieval and server-side scoring
- Notifications
- Certificates endpoint
- KSh 250 subscription/payment record flow
- Admin analytics/content publishing endpoints
- React admin web foundation
- Docker PostgreSQL + Redis development infrastructure

## Important
This repository is an implementation build, not a claim that the product is already deployed or published. Flutter/Android SDK, production hosting, Daraja credentials, Google Play configuration, production secrets, curriculum content and final QA are still required.

## API development
```bash
cd services/api
npm install
npx prisma generate
npm run dev
```

Copy `.env.example` to `.env` and set `DATABASE_URL` and a strong `JWT_SECRET`.

## Mobile development
Flutter SDK is required. From `apps/mobile`:
```bash
flutter pub get
flutter run
```
For an Android emulator, the default API URL is `http://10.0.2.2:4000/api/v1`.

## Admin web
```bash
cd apps/admin_web
npm install
npm run dev
```

## Next required integrations
1. Production PostgreSQL/Redis
2. Daraja sandbox then production adapter
3. Push notification provider
4. Secure object storage
5. Real curriculum/content import and review
6. Automated tests and CI
7. Android signing/AAB build
8. Web deployment and domain
9. Privacy/terms and child-safety review
10. Google Play submission
